# El Secreto La Ventanita

Next.js 15 + React 19 + TypeScript + Tailwind 3.

    npm install
    npm run dev      # http://localhost:3000
    npm run build

Deploy: GitHub → Vercel (Framework: Next.js, sin configuración extra).

- Menú: `data/products.ts` (leído vía `lib/products.ts`, único punto a cambiar al conectar una API).
- Productos con `reviewNote` tienen precios dudosos en las fotos: confirmarlos.
- Teléfono, horarios y combo: `lib/config.ts`.
- Variables: ver `.env.example`.
