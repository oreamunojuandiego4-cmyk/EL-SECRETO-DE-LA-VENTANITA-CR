import type { Metadata, Viewport } from "next";
import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Figtree({ subsets: ["latin"], variable: "--font-body", display: "swap" });

const title = "El Secreto La Ventanita | Comida rápida en Costa Rica";
const description =
  "Hamburguesas, chalupas, nachos, burritos, salchipapas y más. Mirá el menú y pedí por WhatsApp al 8726 8448.";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  title,
  description,
  openGraph: {
    title, description, type: "website", locale: "es_CR", siteName: "El Secreto La Ventanita",
    images: [{ url: "/images/menu-poster.jpg", width: 610, height: 980, alt: "Menú de El Secreto La Ventanita" }],
  },
  twitter: { card: "summary_large_image", title, description },
};

export const viewport: Viewport = { themeColor: "#141110", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-CR" className={`${display.variable} ${body.variable}`}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
