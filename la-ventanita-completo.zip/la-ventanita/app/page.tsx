import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/sections/Hero";
import Menu from "@/sections/Menu";
import Contact from "@/sections/Contact";
import { getProducts } from "@/lib/products";
import { SITE } from "@/lib/config";

export default async function Home() {
  const products = await getProducts();
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FastFoodRestaurant",
    name: SITE.name,
    telephone: "+50687268448",
    servesCuisine: "Comida rápida",
    openingHoursSpecification: [
      { "@type": "OpeningHoursSpecification", dayOfWeek: ["Wednesday", "Thursday", "Friday"], opens: "17:00", closes: "21:00" },
      { "@type": "OpeningHoursSpecification", dayOfWeek: ["Saturday", "Sunday"], opens: "13:00", closes: "21:00" },
    ],
  };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Navbar />
      <main>
        <Hero />
        <Menu products={products} />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
