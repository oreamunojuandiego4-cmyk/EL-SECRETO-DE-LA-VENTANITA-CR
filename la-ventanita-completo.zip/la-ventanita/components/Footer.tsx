import { SITE, whatsappUrl } from "@/lib/config";

export default function Footer() {
  return (
    <footer className="bg-ink px-4 py-10 text-white/70 sm:px-6">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-xl font-extrabold text-white">El Secreto <span className="text-sun">La Ventanita</span></p>
          <p className="mt-1 text-sm">Comida rápida hecha al momento.</p>
        </div>
        <ul className="flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium">
          <li><a className="hover:text-sun" href="#menu">Menú</a></li>
          <li><a className="hover:text-sun" href="#horarios">Horarios</a></li>
          <li><a className="hover:text-sun" href={SITE.tel}>Llamar</a></li>
          <li><a className="hover:text-sun" href={whatsappUrl()} target="_blank" rel="noopener noreferrer">WhatsApp</a></li>
        </ul>
      </div>
      <p className="mx-auto mt-8 max-w-6xl border-t border-white/10 pt-6 text-xs">© {new Date().getFullYear()} {SITE.name}. Todos los derechos reservados.</p>
    </footer>
  );
}
