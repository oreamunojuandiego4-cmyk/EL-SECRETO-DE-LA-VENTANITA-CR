"use client";
import { useState } from "react";
import WhatsAppButton from "./WhatsAppButton";

const links = [
  { href: "#menu", label: "Menú" },
  { href: "#horarios", label: "Horarios" },
  { href: "#contacto", label: "Contacto" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-ink/90 text-white backdrop-blur">
      <nav aria-label="Principal" className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <a href="#inicio" className="font-display text-lg font-extrabold leading-none tracking-tight">
          El Secreto <span className="text-sun">La Ventanita</span>
        </a>
        <ul className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <li key={l.href}><a href={l.href} className="text-sm font-medium text-white/80 transition hover:text-sun">{l.label}</a></li>
          ))}
          <li><WhatsAppButton label="Pedir" className="!min-h-10 !px-5 !py-2 text-sm" /></li>
        </ul>
        <div className="flex items-center gap-2 md:hidden">
          <WhatsAppButton label="Pedir" className="!min-h-10 !px-4 !py-2 text-sm" />
          <button
            type="button" aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Cerrar menú" : "Abrir menú"}
            onClick={() => setOpen((o) => !o)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 transition active:scale-95"
          >
            <span className="relative block h-3 w-5">
              <span className={`absolute left-0 h-0.5 w-5 bg-white transition ${open ? "top-1/2 rotate-45" : "top-0"}`} />
              <span className={`absolute left-0 top-1/2 h-0.5 w-5 bg-white transition ${open ? "opacity-0" : ""}`} />
              <span className={`absolute left-0 h-0.5 w-5 bg-white transition ${open ? "top-1/2 -rotate-45" : "bottom-0"}`} />
            </span>
          </button>
        </div>
      </nav>
      <div id="mobile-menu" hidden={!open} className="border-t border-white/10 bg-ink md:hidden">
        <ul className="mx-auto max-w-6xl px-4 py-2">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} onClick={() => setOpen(false)} className="block rounded-xl px-3 py-4 text-lg font-semibold active:bg-white/10">{l.label}</a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
