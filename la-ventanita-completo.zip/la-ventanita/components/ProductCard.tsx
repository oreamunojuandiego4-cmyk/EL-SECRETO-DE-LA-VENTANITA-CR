import Image from "next/image";
import type { Product } from "@/data/products";
import { formatCRC, whatsappUrl } from "@/lib/config";

export default function ProductCard({ product: p }: { product: Product }) {
  const hasVariants = p.variants.length > 0;
  const msg = `¡Hola! Quiero pedir: ${p.name} 🍔`;
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-3xl bg-white shadow-card transition duration-300 hover:-translate-y-1">
      <div className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-sun to-sun-deep">
        {p.image ? (
          <Image src={p.image} alt={`${p.name} de El Secreto La Ventanita`} fill sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"
            className="object-cover transition duration-500 group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center text-7xl transition duration-300 group-hover:scale-110" aria-hidden="true">{p.emoji}</div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-2xl font-extrabold tracking-tight">{p.name}</h3>
        <p className="mt-1 text-[15px] leading-relaxed text-ink/70">{p.description}</p>

        {hasVariants && (
          <ul className="mt-4 flex flex-wrap gap-2" aria-label={`Opciones de ${p.name}`}>
            {p.variants.map((v) => (
              <li key={v.label} className="rounded-full bg-sun-soft px-3 py-1.5 text-sm font-semibold">
                {v.label} <span className="text-chili">{v.price === null ? "por confirmar" : formatCRC(v.price)}</span>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-auto flex items-end justify-between gap-3 pt-5">
          <p className="font-display text-3xl font-extrabold">
            {p.price === null ? <span className="text-base font-semibold text-ink/60">Precio por confirmar</span> : (
              <>{hasVariants && <span className="mr-1 text-sm font-semibold text-ink/60">desde</span>}{formatCRC(p.price)}</>
            )}
          </p>
          <a href={whatsappUrl(msg)} target="_blank" rel="noopener noreferrer"
            className="inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-sm font-bold text-white transition hover:bg-chili active:scale-95">
            Pedir
          </a>
        </div>
      </div>
    </article>
  );
}
