import { whatsappUrl } from "@/lib/config";

export function WhatsAppIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.4A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-2.9.8.8-2.8-.2-.3A8.2 8.2 0 1 1 12 20.200zM16.600 14.300c-.2-.1-1.500-.7-1.700-.8s-.4-.1-.6.1-.7.8-.8 1-.3.200-.5.100a6.700 6.700 0 0 1-3.300-2.900c-.2-.4.2-.4.700-1.300.1-.2 0-.3 0-.5l-.8-1.900c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.8.4 3.200 3.200 0 0 0-1 2.400 5.600 5.600 0 0 0 1.200 3 12.700 12.700 0 0 0 4.900 4.300c1.800.7 2.500.6 3.300.6a2.800 2.800 0 0 0 1.800-1.300 2.300 2.300 0 0 0 .2-1.300c-.1-.1-.2-.2-.5-.3z" />
    </svg>
  );
}

export default function WhatsAppButton({
  label = "Pedir por WhatsApp", message, className = "", variant = "sun",
}: { label?: string; message?: string; className?: string; variant?: "sun" | "dark" | "ghost" }) {
  const styles = {
    sun: "bg-sun text-ink shadow-pop hover:bg-sun-deep",
    dark: "bg-ink text-white hover:bg-ink-soft",
    ghost: "border border-white/30 text-white hover:bg-white/10",
  }[variant];
  return (
    <a
      href={whatsappUrl(message)} target="_blank" rel="noopener noreferrer"
      className={`inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 py-3 text-base font-bold transition duration-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-95 ${styles} ${className}`}
    >
      <WhatsAppIcon /> {label}
    </a>
  );
}
