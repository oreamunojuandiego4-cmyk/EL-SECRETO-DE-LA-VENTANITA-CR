export type Category = "clasicos" | "carne-o-pollo";

export interface Variant {
  label: string;
  /** null = precio ilegible en la foto, editar luego */
  price: number | null;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: Category;
  /** ruta en /public o null (se muestra emoji) */
  image: string | null;
  emoji: string;
  /** precio base; null = por confirmar */
  price: number | null;
  variants: Variant[];
  /** solo uso interno: dudas de lectura de la foto */
  reviewNote?: string;
}

// Fuente: cartel original + etiquetas amarillas actualizadas (foto 2).
export const products: Product[] = [
  {
    id: "hamburguesa", name: "Hamburguesa", category: "clasicos", emoji: "🍔", image: null,
    description: "La clásica de la casa, bien servida.", price: 2000, variants: [],
    reviewNote: "Hay etiquetas extra (¿doble? ¿con papas?) ilegibles. Confirmar variantes y precios.",
  },
  { id: "doraditas", name: "Doraditas", category: "clasicos", emoji: "🌮", image: null,
    description: "Crujientes y doradas, para el antojo rápido.", price: 1700, variants: [] },
  { id: "papas", name: "Papas", category: "clasicos", emoji: "🍟", image: "/images/papas.jpg",
    description: "Papas fritas calientes y crocantes.", price: 1800, variants: [] },
  { id: "salchipapas", name: "Salchipapas", category: "clasicos", emoji: "🌭", image: "/images/papas.jpg",
    description: "Papas con salchicha, el combo de siempre.", price: 2000, variants: [] },
  { id: "torta-de-carne", name: "Torta de carne", category: "clasicos", emoji: "🥩", image: null,
    description: "Torta de carne bien llena.", price: 1700, variants: [] },
  { id: "palitos-de-queso", name: "Palitos de queso", category: "clasicos", emoji: "🧀", image: null,
    description: "Queso derretido por dentro, dorado por fuera.", price: 2000, variants: [] },
  {
    id: "chalupa", name: "Chalupa", category: "carne-o-pollo", emoji: "🌮", image: null,
    description: "Carne o pollo.", price: 2100,
    variants: [{ label: "Sola", price: 2100 }, { label: "Mixta", price: 2300 }, { label: "Con papas", price: 2600 }],
  },
  {
    id: "papanachos", name: "Papanachos", category: "carne-o-pollo", emoji: "🥔", image: "/images/nachos.jpg",
    description: "Carne o pollo sobre papas, con todo encima.", price: 3200,
    variants: [{ label: "Carne o pollo", price: 3200 }, { label: "Mixtos", price: 3500 }],
  },
  { id: "raviol", name: "Raviol", category: "carne-o-pollo", emoji: "🥟", image: null,
    description: "Carne o pollo.", price: 2000, variants: [] },
  {
    id: "burritos", name: "Burritos", category: "carne-o-pollo", emoji: "🌯", image: "/images/burrito.jpg",
    description: "Carne o pollo, bien enrollados.", price: 2100,
    variants: [{ label: "Sencillo", price: 2100 }, { label: "Mixto", price: 2300 }, { label: "Con papas", price: 2600 }],
  },
  {
    id: "nachos", name: "Nachos", category: "carne-o-pollo", emoji: "🧀", image: "/images/nachos.jpg",
    description: "Totopos con queso, carne o pollo y toppings.", price: 3100,
    variants: [{ label: "Pollo", price: 3100 }, { label: "Mixtos", price: 3300 }],
    reviewNote: "Etiquetas torcidas. Confirmar precio de carne y de pollo.",
  },
  {
    id: "supertaco", name: "Supertaco", category: "carne-o-pollo", emoji: "🌮", image: "/images/burrito.jpg",
    description: "Carne o pollo, tamaño grande.", price: 2100,
    variants: [{ label: "Solo", price: 2100 }, { label: "Con papas", price: 2600 }],
  },
];
