export const SITE = {
  name: "El Secreto La Ventanita",
  phoneDisplay: "8726 8448",
  phoneIntl: "50687268448",
  tel: "tel:+50687268448",
  comboExtra: 1500,
  hours: [
    { days: "Miércoles, jueves y viernes", time: "5:00 PM – 9:00 PM" },
    { days: "Sábado y domingo", time: "1:00 PM – 9:00 PM" },
  ],
};

export function whatsappUrl(message = "¡Hola! Quiero hacer un pedido en El Secreto La Ventanita 🍔") {
  return `https://wa.me/${SITE.phoneIntl}?text=${encodeURIComponent(message)}`;
}

/** 2100 -> "₡2.100" */
export function formatCRC(n: number) {
  return "₡" + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
