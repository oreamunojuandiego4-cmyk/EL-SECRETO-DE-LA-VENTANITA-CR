import { products, type Product } from "@/data/products";

/**
 * Único punto de acceso al menú. Hoy lee datos estáticos;
 * cuando exista backend, reemplazar por:
 *   const res = await fetch(`${process.env.API_BASE_URL}/products`, { next: { revalidate: 60 } });
 *   return (await res.json()) as Product[];
 */
export async function getProducts(): Promise<Product[]> {
  return products;
}
