import Reveal from "@/components/Reveal";
import WhatsAppButton from "@/components/WhatsAppButton";
import { SITE } from "@/lib/config";

export default function Contact() {
  return (
    <>
      <section id="horarios" className="px-4 pb-16 sm:px-6 md:pb-24">
        <Reveal className="mx-auto max-w-6xl">
          <div className="grid gap-4 md:grid-cols-3">
            {SITE.hours.map((h) => (
              <div key={h.days} className="rounded-3xl bg-white p-6 shadow-card">
                <p className="text-sm font-semibold text-ink/60">{h.days}</p>
                <p className="mt-2 font-display text-3xl font-extrabold">{h.time}</p>
              </div>
            ))}
            <a href={SITE.tel} className="rounded-3xl bg-sun p-6 shadow-card transition hover:-translate-y-1 active:scale-[0.99]">
              <p className="text-sm font-semibold text-ink/70">Llamanos</p>
              <p className="mt-2 font-display text-3xl font-extrabold">{SITE.phoneDisplay}</p>
            </a>
          </div>
        </Reveal>
      </section>

      <section id="contacto" className="px-4 pb-16 sm:px-6 md:pb-24">
        <Reveal className="mx-auto max-w-6xl">
          <div className="rounded-[2rem] bg-ink px-6 py-14 text-center text-white sm:px-12">
            <h2 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">¿Se te antojó?</h2>
            <p className="mx-auto mt-4 max-w-md text-lg text-white/75">Hacé tu pedido por WhatsApp y te lo preparamos al momento.</p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <WhatsAppButton label="WhatsApp" />
              <a href={SITE.tel} className="inline-flex min-h-12 items-center justify-center rounded-full border border-white/30 px-6 py-3 text-base font-bold transition duration-200 hover:-translate-y-0.5 hover:bg-white/10 active:scale-95">
                Llamar
              </a>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
