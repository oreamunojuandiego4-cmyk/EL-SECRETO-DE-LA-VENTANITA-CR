import Image from "next/image";
import WhatsAppButton from "@/components/WhatsAppButton";

export default function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden bg-ink text-white">
      <div className="pointer-events-none absolute -left-24 -top-24 h-96 w-96 rounded-full bg-sun/20 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 pb-16 pt-12 sm:px-6 md:grid-cols-[1.1fr_0.9fr] md:pb-24 md:pt-20">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold">
            <span className="h-2 w-2 rounded-full bg-sun" aria-hidden="true" /> Miér a vie desde las 5 PM · Sáb y dom desde la 1 PM
          </p>
          <h1 className="mt-6 font-display text-5xl font-extrabold leading-[0.95] tracking-tight sm:text-7xl lg:text-8xl">
            El Secreto <span className="block text-sun">La Ventanita</span>
          </h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-white/75">
            Hamburguesas, chalupas y nachos calientes, directo de la ventanita a tus manos.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a href="#menu" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-white/30 px-6 py-3 text-base font-bold transition duration-200 hover:-translate-y-0.5 hover:bg-white/10 active:scale-95">
              🍔 Ver menú
            </a>
            <WhatsAppButton label="Pedir por WhatsApp" />
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-[320px]">
          <div className="overflow-hidden rounded-t-full rounded-b-3xl border-[6px] border-sun bg-ink-soft shadow-pop">
            <Image src="/images/menu-poster.jpg" alt="Cartel con el menú de El Secreto La Ventanita" width={610} height={980} priority
              sizes="(min-width:768px) 320px, 80vw" className="h-auto w-full" />
          </div>
          <div className="absolute -bottom-4 -left-2 rotate-[-4deg] rounded-2xl bg-chili px-4 py-2 text-sm font-extrabold shadow-card sm:-left-6">
            ¡Combo por ₡1.500 más!
          </div>
        </div>
      </div>
    </section>
  );
}
