"use client";
import { useState } from "react";
import Reveal from "@/components/Reveal";
import ProductCard from "@/components/ProductCard";
import type { Category, Product } from "@/data/products";
import { SITE, formatCRC } from "@/lib/config";

const tabs: { id: Category | "todo"; label: string }[] = [
  { id: "todo", label: "Todo" },
  { id: "clasicos", label: "Clásicos" },
  { id: "carne-o-pollo", label: "Carne o pollo" },
];

export default function Menu({ products }: { products: Product[] }) {
  const [tab, setTab] = useState<Category | "todo">("todo");
  const shown = tab === "todo" ? products : products.filter((p) => p.category === tab);

  return (
    <section id="menu" className="px-4 py-16 sm:px-6 md:py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <h2 className="font-display text-4xl font-extrabold tracking-tight sm:text-5xl">El menú</h2>
          <p className="mt-3 max-w-xl text-lg text-ink/70">
            Pedilo en combo por {formatCRC(SITE.comboExtra)} más. Precios en colones.
          </p>
        </Reveal>

        <div role="tablist" aria-label="Categorías del menú" className="-mx-4 mt-8 flex gap-2 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
          {tabs.map((t) => (
            <button key={t.id} role="tab" type="button" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
              className={`min-h-11 shrink-0 rounded-full px-5 text-sm font-bold transition active:scale-95 ${
                tab === t.id ? "bg-ink text-sun" : "bg-white text-ink shadow-card hover:bg-sun-soft"}`}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((p, i) => (
            <Reveal key={p.id} delay={(i % 3) * 60}><ProductCard product={p} /></Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
