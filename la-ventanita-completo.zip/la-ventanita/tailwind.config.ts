import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./sections/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        sun: { DEFAULT: "#F6C323", deep: "#E0A800", soft: "#FFF1B8" },
        ink: { DEFAULT: "#141110", soft: "#2A2523" },
        cream: "#FFFBF0",
        chili: "#D2382B",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(20,17,16,.06), 0 12px 32px -12px rgba(20,17,16,.22)",
        pop: "0 18px 50px -18px rgba(246,195,35,.65)",
      },
    },
  },
  plugins: [],
};
export default config;
